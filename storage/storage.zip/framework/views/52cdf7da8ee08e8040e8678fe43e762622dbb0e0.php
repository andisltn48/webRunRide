<?php echo $__env->make('layouts/vLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

      <!-- Sidebar -->
      <ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion" id="accordionSidebar">

          <!-- Sidebar - Brand -->
          <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/dashboard">
              <p class="h3 sidebar-brand-text mx-3">RUNRIDE</p>
          </a>

          <!-- Divider -->
          <hr class="sidebar-divider my-0">

          <!-- Nav Item - Dashboard -->
          <?php if($User->role == 'member'): ?>
          <li class="nav-item active">
            <a class="nav-link" href="/dashboard">
                <i class="fas fa-home"></i>
                <span>Dashboard</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="/pendaftaran">
                <i class="fas fa-plus"></i>
                <span>Pendaftaran</span></a>
          </li>
          <li class="nav-item active">
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($User->email == $item->email): ?>
                <a class="nav-link" href="/pengumpulan")>
                  <i class="fas fa-share-square"></i>
                  <span>Pengumpulan</span>
                </a>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </li>
          <?php endif; ?>
          <!-- Nav Item - Pages Collapse Menu -->

          <?php if($User->role == 'admin'): ?>
            <li class="nav-item active">
            <a class="nav-link" href="/pendaftaran">
                <i class="fas fa-list-ul"></i>
                <span>Daftar Pendaftar</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="/daftaruser">
                    <i class="fas fa-list-ul"></i>
                    <span>Daftar Pengguna</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="/daftarhasil">
                    <i class="fas fa-list-ul"></i>
                    <span>Daftar Hasil</span></a>
            </li>
          <?php endif; ?>
          <!-- Divider -->
          <hr class="sidebar-divider d-none d-md-block">
          <li class="nav-item active">
            <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2"></i>
                <span>Logout</span></a>
          </li>

          <!-- Sidebar Toggler (Sidebar) -->
          <div class="text-center d-none d-md-inline mt-5">
              <button class="rounded-circle border-0" id="sidebarToggle"></button>
          </div>
      </ul>
      <!-- End of Sidebar -->

      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">

          <!-- Main Content -->
          <div id="content">

              <!-- Topbar -->
              <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                  <!-- Sidebar Toggle (Topbar) -->
                  <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                      <i class="fa fa-bars"></i>
                  </button>

                  <!-- Topbar Greeting -->
                  <div class="h3 text-gray-900"><span>Halo, </span> <span class="text-success" id="nama"><?php echo e($User->name); ?></span></div>
                  <?php if(Route::has('login')): ?>
                  <?php if(auth()->guard()->check()): ?>
                  <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Nav Item - User Information -->
                        
                    </ul>
                  <?php endif; ?>
                  <?php endif; ?>
              </nav>
              <!-- End of Topbar -->
              <?php echo $__env->yieldContent('content'); ?>
          </div>
          <!-- End of Main Content -->

          <!-- Footer -->
          <footer class="sticky-footer bg-white">
              <div class="container my-auto">
                  <div class="copyright text-center my-auto">
                      <span>Copyright &copy; </span>
                  </div>
              </div>
          </footer>
          <!-- End of Footer -->

      </div>
      <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
              </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
              
              <form method="POST" action="/logout">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-success">Logout</button>
              </form>
          </div>
      </div>
  </div>
</div>
<script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('js/')); ?>/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/chart.js/Chart.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/chart-area-demo.js')); ?>"></script>
<script src="<?php echo e(asset('js/demo/chart-pie-demo.js')); ?>"></script>
<?php /**PATH D:\projects\WebsiteRama\project\projectForRama\resources\views/layouts/vNav.blade.php ENDPATH**/ ?>