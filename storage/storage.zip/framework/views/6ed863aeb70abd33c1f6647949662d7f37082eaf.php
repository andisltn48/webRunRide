<?php $__env->startSection('content'); ?>
<body>
    <div class="row">
        <div class="col padding-0">
            <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">

                <section class="">
                    <div class="">
                        <section class="home">
                            <div id="carousel" class="carousel slide" data-ride="carousel">
                            <div class="carousel-controls">
                              <ol class="carousel-indicators">
                                <li data-target="#carousel" data-slide-to="0" class="active" ></li>
                                <li data-target="#carousel" data-slide-to="1" ></li>
                                <li data-target="#carousel" data-slide-to="2" ></li>

                              </ol>
                              <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
                                <i class="fa-2x fas fa-arrow-left"></i>
                            </a>
                            <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
                                <i class="fa-2x fas fa-arrow-right"></i>
                            </a>
                            </div>
                            <div class="carousel-inner">
                                <div class="carousel-item active imagebackground " style="background-image:url('<?php echo e(asset('images/feed3.png')); ?>'); background-size: cover;">

                                <div class="container">
                                    <div class="row padding-0">
                                        <div class="col text">
                                            <p class="text-justify ml-3 fs-6 fw-bold text-white"> <span class="fs-4 fw-bolder text-success">   P</span>erkembangan dunia olahraga ini pada umumnya telah mengalami perkembangan pada beberapa tahun terakhir ini yang cukup memuaskan. Potensi-potensi muda telah bermunculan seiring dengan perkembangan dunia olahraga, hal ini tidak lepas dari peran serta dari beberapa pihak  yang  memberikan  support  kepada  seluruh  masyarakat  indonesia  agar  tetap  menjaga kebugaran tubuh di tengah pandemi yang tak kunjung usai ini.</p>
                                        </div>
                                        <div class="col text">
                                            <p class="text-justify ml-3 fs-6 fw-bold text-white"> <span class="fs-4 fw-bolder text-success">   O</span>leh  karena  itu,  maka  kami  menganggap  bahwa  perlunya  untuk  memacu  semangat berolahraga  dari  semua  kalangan  masyarakat  agar  tetap  bisa  menjaga  kesehatan  dan kebugaran  badan  di  tengah  wabah  ini,  maka  dari  sini  kita  mengadakan  acara  HMTI  UMG VIRTUAL  RUN  &  RIDE  NATIONAL  2K21.  Guna  untuk  terus  meningkatakan  semangat berolahraga dan dimana saja bisa dilakukan tanpa harus ke tempat ramai.</p>
                                        </div>
                                        <div class="col secText">
                                            <p class="text-justify ml-3 fs-6 fw-bold text-white"> <span class="fs-4 fw-bolder text-success">   <h3 class="text-white">HMTI UMG Virtual Run <span class="text-success">& Ride National 2k21</span></h3></p>
                                        </div>
                                    </div>
                                    <a href="/pendaftaran"><button class="btn btn-primary mt-5">Daftar Sekarang!</button></a>
                                </div>
                              </div>
                              <div class="carousel-item imagebackground1 " style="background-image:url('<?php echo e(asset('images/feed1blur.jpg')); ?>'); background-size: cover;">

                                <div class="container">
                                    <div class="mb-5 mainimage">
                                        <img class="img-fluid" src="<?php echo e(asset('images/feed2.png')); ?>"  alt="">
                                    </div>
                                </div>
                              </div>
                              <div class="carousel-item imagebackground2" style="background-image:url('<?php echo e(asset('images/feed2blur.jpg')); ?>'); background-size: cover;">

                                <div class="container">
                                    <div class="mb-5 mainimage">
                                        <img class="img-fluid" src="<?php echo e(asset('images/feed1.png')); ?>"  alt="">
                                    </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </section>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/vNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\WebsiteRama\project\projectForRama\resources\views/vDashboard.blade.php ENDPATH**/ ?>