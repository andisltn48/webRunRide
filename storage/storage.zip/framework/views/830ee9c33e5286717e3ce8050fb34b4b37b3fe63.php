<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if(session('pesan')): ?>
    <div class="alert alert-success alert-dismissble">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fas fa-times"></i></button>
    <h4><i class="icon fa fa-check"></i>Success!</h4>
    <?php echo e(session('pesan')); ?>.
    </div>
    <?php endif; ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Pendaftar</h1>

        <form class='navbar-form' action="/searchpendaftar" method="GET">
            <div class='input-group'>
              <input class='form-control' type='text' name='search' placeholder='Seacrh' />

                <button type='submit' class='btn btn-primary'>
                    <i class="fas fa-search"></i>
                </button>


            </div>
        </form>
    </div>
    <a href="/pendaftar/excel" class="btn btn-success my-3" target="_blank">EXPORT EXCEL</a>
    <!-- Content Row -->
    <div class="row">
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Daftar Pendaftar
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Nama</th>
                                <th class="text-center">Email</th>
                                <th class="text-center">Waktu Daftar</th>
                                <th class="text-center">Bukti Pembayaran</th>
                                <th class="text-center">Simpan Bukti Pembayaran</th>
                                <th class="text-center">Detail Data</th>
                                <th class="text-center">Verifikasi</th>
                            </tr>
                        </thead>
                        <?php $__currentLoopData = $allUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                                <tr>
                                    <td><?php echo e($allUser->firstItem()+$key); ?></td>
                                    <td><?php echo e($data->nama); ?></td>
                                    <td><?php echo e($data->email); ?></td>
                                    <td><?php echo e($data->created_at); ?></td>
                                    <td class="text-center"><img class="myImg" src="<?php echo e('images/buktiPembayaran/'.$data->buktipembayaran); ?>" style="width:100%;max-width:50px"></td>
                                    <td class="text-center">
                                        <a href="/detailpendaftar/<?php echo e($data->id); ?>">
                                            <button id="" class="btn btn-success"  type="submit">Simpan</button>
                                        </a>

                                    </td>
                                    <td class="text-center">
                                        <a href="/pembayaran/image/<?php echo e($data->id); ?>">
                                            <button id="" class="btn btn-warning"  type="submit">Detail</button>
                                        </a>

                                    </td>
                                    <td class="text-center">
                                        <form action="<?php echo e(route('verifikasi.pendaftaran.store', $data->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-primary"  type="submit">Konfirmasi</button>
                                        </form>
                                    </td>
                                </tr>
                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <div class="pull-left">
                        showing
                        <?php echo e($allUser->firstItem()); ?>

                        to
                        <?php echo e($allUser->lastItem()); ?>

                    </div>
                    <div class="pull-right">
                        <?php echo e($allUser->links("pagination::bootstrap-4")); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal modalVerifikasi fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
          <div id="result">
          </div>
        
      </div>
    </div>
</div>

<div class="modal modalImage fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content">
      <img id="popup-img" src="" alt="">
    </div>
  </div>
</div>
<script>
$('.myImg').click(function(){
    var src = $(this).attr('src');
    $('.modalImage').modal('show');
    $('#popup-img').attr('src',src);
});
</script>

<script type=text/javascript>

        $("#btnverify1").click(load,function () {

            var iduser = $(this).val();
            $.ajax({
                type:"GET",
                url:"<?php echo e(url('verify')); ?>",
                data:{id:iduser},
                dataType: 'html',
                success:function(data) {
                    // result
                    // window.alert(data);
                    $('#result').append(data);
                    $('.modalVerifikasi').modal('show');



                    // $.each(data,function(key,value){
                    //     $("#state").append('<option value="'+value.id+'">'+value.name+'</option>');
                    // });

                }
            })
        })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/vNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\WebsiteRama\project\projectForRama\resources\views/vAdminHome.blade.php ENDPATH**/ ?>