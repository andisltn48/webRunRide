<?php echo $__env->make('layouts/vLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>
<?php if(Route::has('login')): ?>

    <?php if(auth()->guard()->check()): ?>
    <div class="jumbroton">
        <h1>Welcome</h1>
        <h3>to HMTI UMG Virtual Run & Ride National 2k21</h3>
        <div class="">
            <a class="" href="<?php echo e(url('/pendaftaran')); ?>">
                <button type="button" class="btn btn-primary homebutton">Home</button>
            </a>
        </div>
    </div>
     <?php else: ?>
    <div class="jumbroton">
        <div class="text-primary welcomeText">
            <h1 class="fw-bolder ">Welcome</h1>
        </div>
        <h3 class="text-dark">to HMTI UMG Virtual Run <span class="text-success">& Ride National 2k21</span></h3>
        <div class="text-center">
            <a href="<?php echo e(route('login')); ?>">
                <button type="button" class="btn btn-primary loginbutton">Login</button>
            </a>
        </div>

        <?php if(Route::has('register')): ?>
            <div class="text-center  mt-4">
                <a href="<?php echo e(route('register')); ?>">
                    <button type="button" class="btn btn-primary">Daftar Sekarang!</button>
                </a>
            </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>
</body>
</html>
<?php /**PATH D:\projects\WebsiteRama\project\projectForRama\resources\views/vIndex.blade.php ENDPATH**/ ?>